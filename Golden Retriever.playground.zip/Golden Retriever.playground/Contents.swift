import UIKit
import PlaygroundSupport


//底圖對照
//let image = UIImage(named:"GoldenRetriever.png")
//let imageView = UIImageView(image: image)
//let backgroundView = UIView(frame: imageView.frame)
//backgroundView.addSubview(imageView)
//imageView.alpha = 0.5
//PlaygroundPage.current.liveView = imageView
let rect = CGRect(x: 0, y: 0, width: 300, height: 200)
let backgroundview = UIView(frame: rect)
backgroundview.backgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: 1)


let aDegree = CGFloat.pi / 180

//身體
let path = UIBezierPath()
var point = CGPoint(x: 41 , y: 184)//起點
path.move(to: CGPoint(x: 41 , y: 184))
path.addQuadCurve(to: CGPoint(x: 45 , y: 179), controlPoint: CGPoint(x: 42 , y: 179))
path.addLine(to: CGPoint(x: 58 , y: 176 ))
path.addQuadCurve(to: CGPoint(x: 63 , y: 144), controlPoint: CGPoint(x: 64 , y: 161))
path.addQuadCurve(to: CGPoint(x: 47 , y: 120), controlPoint: CGPoint(x: 54 , y: 131))
path.addLine(to: CGPoint(x: 48 , y: 127))
path.addQuadCurve(to: CGPoint(x: 39 , y: 115), controlPoint: CGPoint(x: 40 , y: 121))
path.addLine(to: CGPoint(x: 37 , y: 117))
path.addQuadCurve(to: CGPoint(x: 38 , y: 92), controlPoint: CGPoint(x: 29 , y: 103))
path.addLine(to: CGPoint(x: 33 , y: 91))
path.addCurve(to: CGPoint(x: 37 , y: 60), controlPoint1: CGPoint(x: 39, y: 75), controlPoint2: CGPoint(x: 32 , y: 75))
path.addQuadCurve(to: CGPoint(x: 23 , y: 57), controlPoint: CGPoint(x: 24 , y: 63))
path.addQuadCurve(to: CGPoint(x: 37 , y: 43), controlPoint: CGPoint(x: 35 , y: 53))
path.addQuadCurve(to: CGPoint(x: 34 , y: 40), controlPoint: CGPoint(x: 38 , y: 35 ))
path.addQuadCurve(to: CGPoint(x: 10 , y: 35 ), controlPoint: CGPoint(x: 15 , y: 46 ))
path.addQuadCurve(to: CGPoint(x: 12 , y: 28 ), controlPoint: CGPoint(x: 4 , y: 30 ))
path.addCurve(to: CGPoint(x: 70 , y: 13 ), controlPoint1: CGPoint(x: 39 , y: 19 ), controlPoint2: CGPoint(x: 25 , y: -5 ))
//path.addCurve(to: CGPoint(x: 70 , y: 13 ), controlPoint1: CGPoint(x: 39 , y: 19 ), controlPoint2: CGPoint(x: 25 , y: 0 ))
path.addCurve(to: CGPoint(x: 123 , y: 56 ), controlPoint1: CGPoint(x: 83 , y: 18 ), controlPoint2: CGPoint(x: 103 , y: 56 ))
path.addQuadCurve(to: CGPoint(x: 239 , y: 71 ), controlPoint: CGPoint(x: 193 , y: 55 ))
path.addQuadCurve(to: CGPoint(x: 279 , y: 44 ), controlPoint: CGPoint(x: 264 , y: 67 ))
path.addQuadCurve(to: CGPoint(x: 269 , y: 79 ), controlPoint: CGPoint(x: 282 , y: 71 ))
path.addLine(to: CGPoint(x: 274 , y: 81 ))
path.addQuadCurve(to: CGPoint(x: 257 , y: 87 ), controlPoint: CGPoint(x: 265 , y: 88 ))
path.addLine(to: CGPoint(x: 262 , y: 90 ))
path.addQuadCurve(to: CGPoint(x: 241 , y: 90 ), controlPoint: CGPoint(x: 247 , y: 95 ))
path.addLine(to: CGPoint(x: 247 , y: 95 ))
path.addQuadCurve(to: CGPoint(x: 231 , y: 94 ), controlPoint: CGPoint(x: 237 , y: 98 ))
path.addLine(to: CGPoint(x: 235 , y: 104 ))
path.addLine(to: CGPoint(x: 235 , y: 105 ))
path.addLine(to: CGPoint(x: 235 , y: 118 ))
path.addLine(to: CGPoint(x: 235 , y: 119 ))
path.addLine(to: CGPoint(x: 231 , y: 137 ))
path.addLine(to: CGPoint(x: 229 , y: 134 ))
path.addQuadCurve(to: CGPoint(x: 232 , y: 163 ), controlPoint: CGPoint(x: 224 , y: 149 ))
path.addQuadCurve(to: CGPoint(x: 232 , y: 171 ), controlPoint: CGPoint(x: 237 , y: 168 ))
path.addQuadCurve(to: CGPoint(x: 229 , y: 184 ), controlPoint: CGPoint(x: 228 , y: 175 ))//底部y=184
path.addLine(to: CGPoint(x: 210 , y: 184 ))
path.addQuadCurve(to: CGPoint(x: 214 , y: 179 ), controlPoint: CGPoint(x: 208 , y: 179 ))
path.addQuadCurve(to: CGPoint(x: 215 , y: 159 ), controlPoint: CGPoint(x: 221 , y: 162 ))
path.addLine(to: CGPoint(x: 200 , y: 184 ))
path.addLine(to: CGPoint(x: 174 , y: 184 ))
path.addQuadCurve(to: CGPoint(x: 183 , y: 178 ), controlPoint: CGPoint(x: 174 , y: 180 ))
path.addLine(to: CGPoint(x: 189 , y: 179 ))
path.addCurve(to: CGPoint(x: 185 , y: 131 ), controlPoint1: CGPoint(x: 196 , y: 149 ), controlPoint2: CGPoint(x: 184 , y: 145 ))
path.addQuadCurve(to: CGPoint(x: 170 , y: 137 ), controlPoint: CGPoint(x: 177 , y: 139 ))
path.addLine(to: CGPoint(x: 173 ,y:130))
path.addLine(to: CGPoint(x: 159 , y: 135 ))
path.addQuadCurve(to: CGPoint(x: 151 , y: 128 ), controlPoint: CGPoint(x: 154 , y: 122 ))
path.addQuadCurve(to: CGPoint(x: 141 , y: 135 ), controlPoint: CGPoint(x: 150 , y: 133 ))
path.addQuadCurve(to: CGPoint(x: 139 , y: 130 ), controlPoint: CGPoint(x: 147 , y: 123 ))
path.addQuadCurve(to: CGPoint(x: 126 , y: 138 ), controlPoint: CGPoint(x: 132 , y: 139 ))
path.addLine(to: CGPoint(x: 124 , y: 132 ))
path.addLine(to: CGPoint(x: 118 , y: 139 ))
path.addLine(to: CGPoint(x: 117 , y: 136 ))
path.addLine(to: CGPoint(x: 106 , y: 141 ))
path.addLine(to: CGPoint(x: 107 , y: 148 ))
path.addQuadCurve(to: CGPoint(x: 99 , y: 169 ), controlPoint: CGPoint(x: 99 , y: 157 ))
path.addQuadCurve(to: CGPoint(x: 88 , y: 184 ), controlPoint: CGPoint(x: 90 , y: 175 ))
path.addLine(to: CGPoint(x: 79 , y: 184 ))
path.addLine(to: CGPoint(x: 41 , y: 184 ))
path.close()

//狗狗身體CAShapeLayer轉換
let Goldenlayer = CAShapeLayer()
Goldenlayer.path = path.cgPath

//生成一個view
let Goldenframe = CGRect(x: 0, y: 0, width: 400, height: 400)
let Goldenview = UIView(frame: Goldenframe)
//狗狗顏色
Goldenview.backgroundColor = UIColor(red: 255/255, green: 196/255, blue: 37/255, alpha: 1)

//mask
Goldenview.layer.mask = Goldenlayer



//狗狗眼睛
let eyepath = UIBezierPath(ovalIn: CGRect(x: 40, y: 22, width: 5, height: 5))

//狗狗眼睛CAShapeLayer轉換
let Eyelayer = CAShapeLayer()
Eyelayer.path = eyepath.cgPath

//生成眼睛的view
let Eyeframe = CGRect(x: 0, y: 0, width: 300, height: 200)
let Eyeview = UIView(frame: Eyeframe)
Eyeview.backgroundColor = UIColor(red: 1/255, green: 1/255, blue: 0, alpha: 1)

Eyeview.layer.mask = Eyelayer


//球
let ballpath = UIBezierPath(ovalIn: CGRect(x: 12, y: 37, width: 20, height: 20))

let balllayer = CAShapeLayer()
balllayer.path = ballpath.cgPath

//生成球的view
let ballview = UIView(frame: CGRect(x: 0, y: 0, width: 300, height: 200))
ballview.backgroundColor = UIColor(red: 1, green: 12/255, blue: 0/255, alpha: 0.85)

ballview.layer.mask = balllayer


//狗狗鼻子
let nosepath = UIBezierPath(ovalIn: CGRect(x: 8.5, y: 29, width: 3, height: 5))

//狗狗眼睛CAShapeLayer轉換
let noselayer = CAShapeLayer()
noselayer.path = nosepath.cgPath

//生成眼睛的view
let noseframe = CGRect(x: 0, y: 0, width: 300, height: 200)
let noseview = UIView(frame: Eyeframe)
noseview.backgroundColor = UIColor(red: 1/255, green: 1/255, blue: 0, alpha: 1)

noseview.layer.mask = noselayer


backgroundview.addSubview(ballview)
backgroundview.addSubview(Goldenview)
backgroundview.addSubview(Eyeview)
backgroundview.addSubview(noseview)




PlaygroundPage.current.liveView = backgroundview













